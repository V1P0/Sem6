package com.example.l2z1

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.GridLayout
import android.widget.SeekBar
import android.widget.TableLayout
import android.widget.TableRow
import android.widget.TextView
import java.lang.Integer.min

class MainActivity : AppCompatActivity() {
    var buttons = Array(9) { arrayOfNulls<Button>(9) }
    var firstClick = true
    var board = Array(9) { Array(9) { 0 } }
    var numberOfBombs = 20
    var freeSquares = 81
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val displayMetrics = resources.displayMetrics
        val width = displayMetrics.widthPixels
        val height = displayMetrics.heightPixels


        val buttonSize = min(width, height)/9
        for(i in 0..8) {
            val row = TableRow(this)
            for(j in 0..8) {
                buttons[i][j] = Button(this)
                buttons[i][j]?.layoutParams = TableRow.LayoutParams(buttonSize, buttonSize)
                buttons[i][j]?.text = "X"
                buttons[i][j]?.setBackgroundColor(Color.WHITE)
                buttons[i][j]?.setOnClickListener {
                    click(i, j)
                }
                buttons[i][j]?.setOnLongClickListener {
                    hold(i, j)
                    true
                }
                row.addView(buttons[i][j])
            }
            findViewById<TableLayout>(R.id.tableLayout).addView(row)
        }

        findViewById<SeekBar>(R.id.seekBar).setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                numberOfBombs = progress
                findViewById<TextView>(R.id.textView).text = numberOfBombs.toString()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
            }
        })
    }

    private fun click(i: Int, j: Int) {
        if(firstClick) {
            generateBoard(i, j)
            firstClick = false
        }
        if(buttons[i][j]?.text != "X") {
            return
        }
        buttons[i][j]?.setBackgroundColor(Color.BLACK)
        if(board[i][j] == -1) {
            gameLost()
            return
        }
        buttons[i][j]?.text = if (board[i][j] != 0) {board[i][j].toString()} else {""}
        freeSquares--
        findViewById<TextView>(R.id.infoTextView).text = freeSquares.toString()
        if(freeSquares == 0) {
            findViewById<TextView>(R.id.infoTextView).setText(R.string.win)
        }
        if(board[i][j]==0) {
            for(k in -1..1) {
                for(l in -1..1) {
                    if(i+k < 0 || i+k > 8 || j+l < 0 || j+l > 8) {
                        continue
                    }
                    click(i+k, j+l)
                }
            }
        }
    }

    private fun gameLost() {
        findViewById<TextView>(R.id.infoTextView).setText(R.string.lose)
        for(i in 0..8) {
            for(j in 0..8) {
                if(board[i][j] == -1) {
                    if(buttons[i][j]?.text == "P"){
                        buttons[i][j]?.setBackgroundColor(Color.GREEN)
                    }else{
                        buttons[i][j]?.setBackgroundColor(Color.RED)
                    }
                    buttons[i][j]?.text = "B"
                }
            }
        }
    }

    private fun hold(i: Int, j: Int) {
        if(buttons[i][j]?.text == "X") {
            buttons[i][j]?.text = "P"
            buttons[i][j]?.setBackgroundColor(Color.GRAY)
        }else if(buttons[i][j]?.text == "P") {
            buttons[i][j]?.text = "X"
            buttons[i][j]?.setBackgroundColor(Color.WHITE)
        }
    }

    private fun generateBoard(x: Int, y: Int) {
        var bombs = Array(9*9-1) { false }
        var m = numberOfBombs
        freeSquares = 81 - m
        findViewById<TextView>(R.id.infoTextView).text = freeSquares.toString()
        //add m bombs in random places
        while(m > 0) {
            bombs[m-1] = true
            m--
        }
        bombs.shuffle()
        for(i in 0..8) {
            for(j in 0..8) {
                if(i == x && j == y) {
                    board[i][j] = 0
                }else{
                    if(bombs[m]){
                        board[i][j] = -1
                    }
                    m++
                }
            }
        }
        for(i in 0..8) {
            for(j in 0..8) {
                if(board[i][j] == -1) {
                    continue
                }
                var count = 0
                for(k in -1..1) {
                    for(l in -1..1) {
                        if(i+k < 0 || i+k > 8 || j+l < 0 || j+l > 8) {
                            continue
                        }
                        if(board[i+k][j+l] == -1) {
                            count++
                        }
                    }
                }
                board[i][j] = count
            }
        }
    }
    fun restart(view: View){
        firstClick = true
        freeSquares = 81
        findViewById<TextView>(R.id.infoTextView).setText(R.string.info)
        for(i in 0..8) {
            for(j in 0..8) {
                board[i][j] = 0
                buttons[i][j]?.text = "X"
                buttons[i][j]?.setBackgroundColor(Color.WHITE)
            }
        }
    }

}