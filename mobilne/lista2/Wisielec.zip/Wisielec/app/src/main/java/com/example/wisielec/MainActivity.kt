package com.example.wisielec

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    var word = ""
    var usedLetters = mutableListOf<Char>()
    var wrongGuesses = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        word = resources.getStringArray(R.array.words)[(0..resources.getStringArray(R.array.words).size).random()]
        var wordLen = word.length
        var wordToGuess = "*".repeat(wordLen)
        findViewById<TextView>(R.id.wordTextView).text = wordToGuess
        Log.i("word", word)
    }

    fun reset(view: View) {
        word = resources.getStringArray(R.array.words)[(0..resources.getStringArray(R.array.words).size).random()]
        wrongGuesses = 0
        var wordLen = word.length
        var wordToGuess = "*".repeat(wordLen)
        findViewById<TextView>(R.id.wordTextView).text = wordToGuess
        Log.i("word", word)
        usedLetters.clear()
        findViewById<TextView>(R.id.usedLettersTextView).text = usedLetters.toString().subSequence(1, usedLetters.toString().length-1)
        findViewById<ImageView>(R.id.imageView).setImageResource(resources.getIdentifier("wisielec0", "drawable", packageName))
    }

    fun tryLetter(view: View) {
        if(wrongGuesses == 10){
            Toast.makeText(this, "Przegrałeś!", Toast.LENGTH_SHORT).show()
            return
        }
        var inputLetter = findViewById<EditText>(R.id.inputLetter);
        var wordInput = inputLetter.text
        if (wordInput.length != 1) {
            Toast.makeText(this, "Wpisz tylko jedną literę!", Toast.LENGTH_SHORT).show()
            return
        }
        var letter = wordInput[0]
        if (usedLetters.contains(letter)) {
            Toast.makeText(this, "Ta litera została już użyta!", Toast.LENGTH_SHORT).show()
        } else {
            usedLetters.add(letter)
            findViewById<TextView>(R.id.usedLettersTextView).text = usedLetters.toString().subSequence(1, usedLetters.toString().length-1)
            if (word.contains(letter)) {
                Toast.makeText(this, "Zgadłeś!", Toast.LENGTH_SHORT).show()
                var wordTextView = findViewById<TextView>(R.id.wordTextView)
                var wordToGuess = wordTextView.text
                for (i in word.indices) {
                    if (word[i] == letter) {
                        wordToGuess = wordToGuess.replaceRange(i, i+1, letter.toString())
                    }
                }
                if(word.equals(wordToGuess.toString())){
                    Toast.makeText(this, "Wygrałeś!", Toast.LENGTH_LONG).show()
                }
                wordTextView.text = wordToGuess
            } else {
                mistake()
            }
        }
        inputLetter.text.clear()
    }

    fun mistake(){
        Toast.makeText(this, "Nie zgadłeś!", Toast.LENGTH_SHORT).show()
        wrongGuesses++
        findViewById<ImageView>(R.id.imageView).setImageResource(resources.getIdentifier("wisielec$wrongGuesses", "drawable", packageName))

    }
}