package com.example.calendar.calendarView

import android.content.Intent
import android.view.View
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView.ViewHolder
import com.example.calendar.DayEventsActivity
import com.example.calendar.R
import java.time.LocalDate

class MonthViewHolder(itemView: View) : ViewHolder(itemView), View.OnClickListener {
    val dayOfMonth: TextView
    var date:LocalDate = LocalDate.now()

    init {
        dayOfMonth = itemView.findViewById(R.id.cellDayText)
        itemView.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        if(dayOfMonth.text == "") return
        //go to activity activity_day_events with date
        var intent = Intent(v?.context, DayEventsActivity::class.java)
        intent.putExtra("date", date.toString())
        v?.context?.startActivity(intent)

    }
}