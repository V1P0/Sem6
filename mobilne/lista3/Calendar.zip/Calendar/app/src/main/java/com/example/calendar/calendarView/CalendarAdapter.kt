package com.example.calendar.calendarView

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.calendar.R
import java.time.LocalDate

class CalendarAdapter : RecyclerView.Adapter<CalendarViewHolder>()  {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CalendarViewHolder {
        var inflater = LayoutInflater.from(parent.context)
        var view = inflater.inflate(R.layout.month_item, parent, false)
        return CalendarViewHolder(view)
    }

    override fun getItemCount(): Int {
        return Int.MAX_VALUE
    }

    override fun onBindViewHolder(holder: CalendarViewHolder, position: Int) {
        holder.setMonthView(LocalDate.ofYearDay(1970, 1).plusMonths(position.toLong()))
    }

}