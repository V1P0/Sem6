package com.example.calendar.database

class DayEventDaoMock:DayEventDao {
    val events = mutableListOf<DayEvent>()
    init{
        addEvents(
            DayEvent(null, "2023-04-16", 12, 0, 13, 0, "Event 1", "Description 1"),
            DayEvent(null, "2023-04-16", 13, 0, 14, 0, "Event 2", "Description 2"),
            DayEvent(null, "2023-04-16", 14, 0, 15, 0, "Event 3", "Description 3"),
        )
    }
    override fun getEventById(id: Int): List<DayEvent> {
        return events.filter { it.Id == id }
    }

    override fun getDayEvents(date: String): List<DayEvent> {
        return events.filter { it.date == date }
    }

    override fun addEvents(vararg dayEvents: DayEvent) {
        var id = events.size
        for(event in dayEvents) {
            event.Id = id
            events.add(event)
            id++
        }
    }

    override fun delete(dayEvent: DayEvent) {
        events.remove(dayEvent)
    }
}