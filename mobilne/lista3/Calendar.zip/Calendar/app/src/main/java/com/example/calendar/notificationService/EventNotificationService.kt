package com.example.calendar.notificationService

import android.Manifest
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.os.IBinder
import android.util.Log
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.calendar.App
import com.example.calendar.R
import com.example.calendar.calendarView.MainActivity
import com.example.calendar.database.DatabaseManager
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime

class EventNotificationService: Service() {
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.i("Notification", "Notification service started")
        var db = DatabaseManager.getInstance()
        var events = db.getEventsFromTo(LocalDate.now(), LocalDate.now().plusDays(1))
        var notId = 1
        for (event in events){
            var eventDateTime = LocalDateTime.of(LocalDate.parse(event.date), LocalTime.of(event.StartHour, event.StartMinute))
            var nowDateTime = LocalDateTime.now()
            if (eventDateTime.isAfter(nowDateTime) && eventDateTime.minusHours(1).isBefore(nowDateTime)){
                var notification = NotificationCompat.Builder(this, App.CHANNEL_ID)
                    .setSmallIcon(R.drawable.ic_launcher_foreground)
                    .setContentTitle("Upcoming event")
                    .setContentText(event.Title+" is starting on "+event.date + " at "+event.StartHour+":"+event.StartMinute)
                    .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                    .setAutoCancel(true)
                    .build()
                //send notification
                var notificationManager = NotificationManagerCompat.from(this)
                notificationManager.notify(notId, notification)
                notId++
                Log.i("Notification", "Notification sent")
            }
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }
}