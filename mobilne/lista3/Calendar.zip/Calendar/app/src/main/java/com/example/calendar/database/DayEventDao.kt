package com.example.calendar.database

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query

@Dao
interface DayEventDao {

    @Query("SELECT * FROM day_event WHERE Id = :id")
    fun getEventById(id: Int): List<DayEvent>

    @Query("SELECT * FROM day_event WHERE date = :date")
    fun getDayEvents(date: String): List<DayEvent>

    @Insert
    fun addEvents(vararg dayEvents: DayEvent)

    @Delete
    fun delete(dayEvent: DayEvent)

}