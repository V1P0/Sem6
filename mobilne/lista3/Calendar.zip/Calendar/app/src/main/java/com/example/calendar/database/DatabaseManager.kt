package com.example.calendar.database

import android.app.Application
import android.util.Log
import androidx.room.Room
import java.time.LocalDate
import java.time.LocalTime

class DatabaseManager(val eventDao: DayEventDao) {
    init{

    }
    companion object {
        private var instance: DatabaseManager? = null
        fun getInstance(): DatabaseManager {
            if (instance == null) {
                instance = DatabaseManager(DayEventDaoMock())
            }
            return instance!!
        }
        fun setDB(eventDao: DayEventDao) {
            instance = DatabaseManager(eventDao)
        }
    }

    fun getEventsOnDate(date: LocalDate): List<DayEvent> {
        return eventDao.getDayEvents(date.toString())
    }

    fun addEvent(date: LocalDate, title:String, startTime: LocalTime, endTime: LocalTime, description: String) {
        eventDao.addEvents(DayEvent(null, date.toString(), startTime.hour, startTime.minute, endTime.hour, endTime.minute, title, description))
    }

    fun hasEvent(date: LocalDate): Boolean {
        return eventDao.getDayEvents(date.toString()).isNotEmpty()
    }

    fun getEventById(id: Int): DayEvent? {
        return eventDao.getEventById(id).firstOrNull()
    }

    fun deleteEvent(date: LocalDate, id: Int) {
        eventDao.delete(getEventById(id)!!)
    }

    fun getEventsFromTo(startDate: LocalDate, endDate: LocalDate): List<DayEvent> {
        val events = mutableListOf<DayEvent>()
        var date = startDate
        while(!endDate.isBefore(date)) {
            events.addAll(getEventsOnDate(date))
            date = date.plusDays(1)
        }
        return events
    }
}