package com.example.calendar

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.util.Log
import androidx.room.Room
import com.example.calendar.calendarView.MainActivity
import com.example.calendar.database.AppDatabase
import com.example.calendar.database.DatabaseManager
import com.example.calendar.notificationService.EventNotificationService

class App: Application() {
    companion object{
        val CHANNEL_ID = "EventNotificationService"
    }
    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        Log.i("App", "App started")
        var db = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java, "myCalendar"
        ).allowMainThreadQueries().build()
        DatabaseManager.setDB(db.dayEventDao())
        var intent = Intent(this, EventNotificationService::class.java)
        var pendingIntent = PendingIntent.getService(this, 0, intent, PendingIntent.FLAG_MUTABLE)
        var alarmManager = getSystemService(ALARM_SERVICE) as android.app.AlarmManager
        alarmManager.setRepeating(android.app.AlarmManager.RTC_WAKEUP, System.currentTimeMillis(), 1000*60, pendingIntent)
    }

    fun createNotificationChannel(){
        var serviceChannel = NotificationChannel(
            CHANNEL_ID,
            "EventNotificationService",
            NotificationManager.IMPORTANCE_DEFAULT
        )

        var manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(serviceChannel)
    }
}