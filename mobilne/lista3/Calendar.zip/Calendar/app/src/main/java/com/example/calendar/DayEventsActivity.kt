package com.example.calendar

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.TextView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.calculateTargetValue
import androidx.compose.animation.splineBasedDecay
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.horizontalDrag
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.*
import androidx.compose.ui.platform.ComposeView
import com.example.calendar.database.DatabaseManager
import com.example.calendar.database.DayEvent
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import java.util.*
import kotlin.math.absoluteValue
import kotlin.math.roundToInt

class DayEventsActivity : AppCompatActivity() {
    lateinit var events:List<DayEvent>
    var date:LocalDate = LocalDate.now()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_day_events)
        val dateString = intent.getStringExtra("date")
        date = LocalDate.parse(dateString)
        var textView = findViewById<TextView>(R.id.textView2)
        val formatter: DateTimeFormatter = DateTimeFormatter.ofPattern("dd MMMM yyyy")
        textView.text = date.format(formatter)
        events = DatabaseManager.getInstance().getEventsOnDate(date)
        addEvents()
    }

    override fun onResume() {
        super.onResume()
        events = DatabaseManager.getInstance().getEventsOnDate(date)
        addEvents()
    }

    fun addEvents(){
        Log.i("events", events.toString())
        var layout = findViewById<ComposeView>(R.id.composeView)
        events = events.sortedBy { it.StartHour*60+it.StartMinute }
        if(events.isEmpty()){
            layout.apply {
                setContent {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "No events on this day",
                            style = MaterialTheme.typography.h5,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
            return
        }
        layout.apply {
            setContent {
                EventList()
            }
        }
    }
    @Composable
    fun EventList(){
        var expandedTopic by remember { mutableStateOf<Int?>(null) }
        val lazyListState = rememberLazyListState()

        LazyColumn(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 32.dp),
            state = lazyListState,
        ) {


            // Topics
            items(events.size) { topicNumber ->
                TopicRow(
                    title = events[topicNumber].Title,
                    time = events[topicNumber].StartHour.toString() + ":" + events[topicNumber].StartMinute.toString().padStart(2, '0') + " - " +
                            events[topicNumber].EndHour.toString() + ":" + events[topicNumber].EndMinute.toString().padStart(2, '0'),
                    description = events[topicNumber].Description,
                    expanded = expandedTopic == events[topicNumber].Id,
                    onClick = {
                        expandedTopic = if (expandedTopic == events[topicNumber].Id) null else events[topicNumber].Id
                    },
                    onDismissed = {
                        DatabaseManager.getInstance().deleteEvent(date, events[topicNumber].Id!!)
                        events = DatabaseManager.getInstance().getEventsOnDate(date)
                        addEvents()
                    }
                )
            }
            item { Spacer(modifier = Modifier.height(32.dp)) }
        }
    }
    @Composable
    fun TopicRowSpacer(visible: Boolean) {
        AnimatedVisibility(visible = visible) {
            Spacer(modifier = Modifier.height(8.dp))
        }
    }
    @OptIn(ExperimentalMaterialApi::class)
    @Composable
    fun TopicRow(title: String, time: String, description:String, expanded: Boolean, onClick: () -> Unit, onDismissed: () -> Unit) {
        TopicRowSpacer(visible = expanded)
        Surface(
            modifier = Modifier
                .fillMaxWidth(),
            elevation = 2.dp,
            onClick = onClick,
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .swipeToDismiss(onDismissed)
                    .animateContentSize()
            ) {
                Row() {
                    Text(
                        text = title,
                        modifier = Modifier.weight(5f),
                        style = MaterialTheme.typography.body1
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Text(
                        text = time,
                        modifier = Modifier.weight(5f),
                        style = MaterialTheme.typography.body1
                    )

                }
                if (expanded) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = description,
                        textAlign = TextAlign.Justify
                    )
                }
            }
        }
        TopicRowSpacer(visible = expanded)
    }

    fun addNevEvent(view: View) {
        var intent = Intent(this, AddEvent::class.java)
        intent.putExtra("date", date.toString())
        startActivity(intent)
    }

    private fun Modifier.swipeToDismiss(
        onDismissed: () -> Unit
    ): Modifier = composed {
        val offsetX = remember { androidx.compose.animation.core.Animatable(0f) }

        pointerInput(Unit) {
            val decay = splineBasedDecay<Float>(this)
            coroutineScope {
                while (true) {
                    val pointerId = awaitPointerEventScope { awaitFirstDown().id }
                    offsetX.stop()
                    val velocityTracker = VelocityTracker()
                    awaitPointerEventScope {
                        horizontalDrag(pointerId) { change ->
                            val horizontalDragOffset = offsetX.value + change.positionChange().x
                            launch {
                                offsetX.snapTo(horizontalDragOffset)
                            }
                            velocityTracker.addPosition(change.uptimeMillis, change.position)
                            if (change.positionChange() != Offset.Zero) change.consume()
                        }
                    }
                    val velocity = velocityTracker.calculateVelocity().x
                    val targetOffsetX = decay.calculateTargetValue(offsetX.value, velocity)
                    offsetX.updateBounds(
                        lowerBound = -size.width.toFloat(),
                        upperBound = size.width.toFloat()
                    )
                    launch {
                        if (targetOffsetX.absoluteValue <= size.width) {
                            offsetX.animateTo(targetValue = 0f, initialVelocity = velocity)
                        } else {
                            offsetX.animateDecay(velocity, decay)
                            onDismissed()
                            offsetX.animateTo(targetValue = 0f, initialVelocity = 0f)
                        }
                    }
                }
            }
        }
            .offset { IntOffset(offsetX.value.roundToInt(), 0) }

    }
}

