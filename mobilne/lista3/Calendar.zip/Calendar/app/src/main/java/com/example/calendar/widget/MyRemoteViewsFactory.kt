package com.example.calendar.widget

import android.content.Context
import android.util.Log
import android.widget.RemoteViews
import android.widget.RemoteViewsService
import androidx.room.Room
import com.example.calendar.R
import com.example.calendar.database.AppDatabase
import com.example.calendar.database.DatabaseManager
import com.example.calendar.database.DayEvent
import java.time.LocalDate

class MyRemoteViewsFactory(private val context: Context) : RemoteViewsService.RemoteViewsFactory {
    private val dayEvents = mutableListOf<DayEvent>()
    private val db = Room.databaseBuilder(
        context,
        AppDatabase::class.java, "myCalendar"
    ).build()

    override fun onCreate() {
        DatabaseManager.setDB(db.dayEventDao())
        dayEvents.addAll(DatabaseManager.getInstance().getEventsFromTo(LocalDate.now(), LocalDate.now().plusDays(7)))
    }

    override fun onDataSetChanged() {
        dayEvents.clear()
        dayEvents.addAll(DatabaseManager.getInstance().getEventsFromTo(LocalDate.now(), LocalDate.now().plusDays(7)))
    }

    override fun onDestroy() {
    }

    override fun getCount(): Int {
        return dayEvents.size
    }

    override fun getViewAt(position: Int): RemoteViews {
        Log.i("MyRemoteViewsFactory", "getViewAt: $position")
        val rv = RemoteViews(context.packageName, R.layout.day_event_preview)
        rv.setTextViewText(R.id.dayEventDescription, dayEvents[position].Title)
        rv.setTextViewText(R.id.startTime, dayEvents[position].StartHour.toString() + ":" + dayEvents[position].StartMinute.toString())
        rv.setTextViewText(R.id.endTime, dayEvents[position].EndHour.toString() + ":" + dayEvents[position].EndMinute.toString())
        return rv
    }

    override fun getLoadingView(): RemoteViews? {
        return null
    }

    override fun getViewTypeCount(): Int {
        return 1
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun hasStableIds(): Boolean {
        return true
    }
}
