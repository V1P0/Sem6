package com.example.calendar.database

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.time.LocalTime
@Entity(tableName = "day_event")
class DayEvent (@PrimaryKey(autoGenerate = true) var Id: Int? = null,
                var date: String,
                var StartHour: Int,
                var StartMinute: Int,
                var EndHour: Int,
                var EndMinute: Int,
                var Title: String,
                var Description: String)