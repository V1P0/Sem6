package com.example.calendar.calendarView

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.LinearSnapHelper
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.example.calendar.R
import com.example.calendar.database.AppDatabase
import com.example.calendar.database.DatabaseManager
import com.example.calendar.notificationService.EventNotificationService
import www.sanju.zoomrecyclerlayout.ZoomRecyclerLayout
import java.time.LocalDate
import java.util.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.i("App", "App MainActivity")
        setContentView(R.layout.activity_main)
        var recyclerView = findViewById<RecyclerView>(R.id.recycler)
        val snapHelper = LinearSnapHelper()
        snapHelper.attachToRecyclerView(recyclerView)
        recyclerView.isNestedScrollingEnabled = false
        val linearLayoutManager = ZoomRecyclerLayout(this)
        linearLayoutManager.orientation = LinearLayoutManager.HORIZONTAL
        recyclerView.layoutManager = linearLayoutManager
        var calendarAdapter = CalendarAdapter()
        recyclerView.adapter = calendarAdapter
        recyclerView.scrollToPosition(LocalDate.now().monthValue+12*(LocalDate.now().year-1970)-1)
    }



    override fun onResume() {
        super.onResume()
        var recyclerView = findViewById<RecyclerView>(R.id.recycler)
        recyclerView.adapter?.notifyDataSetChanged()
    }



}