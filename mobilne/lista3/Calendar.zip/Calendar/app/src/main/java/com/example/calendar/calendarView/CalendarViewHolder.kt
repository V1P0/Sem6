package com.example.calendar.calendarView

import android.view.View
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.calendar.R
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter

class CalendarViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    val monthYear: TextView
    val calendarRecyclerView: RecyclerView

    init {
        monthYear = itemView.findViewById(R.id.monthYear)
        monthYear.setOnClickListener {
        }
        calendarRecyclerView = itemView.findViewById(R.id.calendarRecyclerView)

    }

    fun setMonthView(selectedDate: LocalDate){
        val formatter: DateTimeFormatter = DateTimeFormatter.ofPattern("MMMM yyyy")
        monthYear.text = selectedDate.format(formatter)
        var daysInMonth = daysInMonthArray(selectedDate)

        var monthAdapter = MonthAdapter(daysInMonth, selectedDate)
        var layoutManager = GridLayoutManager(itemView.context, 7)
        calendarRecyclerView.layoutManager = layoutManager
        calendarRecyclerView.adapter = monthAdapter
    }

    fun daysInMonthArray(date: LocalDate) : Array<String>{
        var daysInMonthArray = Array(42) {""}
        var yearMonth = YearMonth.from(date)
        var daysInMonth = yearMonth.lengthOfMonth()
        var firstOfMonth = date.withDayOfMonth(1)
        var dayOfWeek = firstOfMonth.dayOfWeek.value
        for(i in 1..42){
            if(i in dayOfWeek until daysInMonth+dayOfWeek){
                daysInMonthArray[i-1] = (i-dayOfWeek+1).toString()
            }else{
                daysInMonthArray[i-1] = ""
            }
        }
        return daysInMonthArray
    }
}