package com.example.calendar

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.MultiAutoCompleteTextView
import android.widget.TimePicker
import android.widget.Toast
import com.example.calendar.database.DatabaseManager
import java.time.LocalDate
import java.time.LocalTime

class AddEvent : AppCompatActivity() {
    lateinit var startTimeSelector : TimePicker
    lateinit var endTimeSelector : TimePicker
    lateinit var titleSelector: EditText
    lateinit var descriptionSelector: MultiAutoCompleteTextView
    lateinit var date: LocalDate
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_event)
        startTimeSelector = findViewById(R.id.start_time_picker)
        startTimeSelector.setIs24HourView(true)
        endTimeSelector = findViewById(R.id.end_time_picker)
        endTimeSelector.setIs24HourView(true)
        titleSelector = findViewById(R.id.title_input)
        descriptionSelector = findViewById(R.id.description_input)
        date = LocalDate.parse(intent.getStringExtra("date"))
    }

    override fun onSaveInstanceState(outState: Bundle) {

        outState.putInt("startHour", startTimeSelector.hour)
        outState.putInt("startMinute", startTimeSelector.minute)
        outState.putInt("endHour", endTimeSelector.hour)
        outState.putInt("endMinute", endTimeSelector.minute)
        outState.putString("title", titleSelector.text.toString())
        outState.putString("description", descriptionSelector.text.toString())
        super.onSaveInstanceState(outState)
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        startTimeSelector.hour = savedInstanceState.getInt("startHour")
        startTimeSelector.minute = savedInstanceState.getInt("startMinute")
        endTimeSelector.hour = savedInstanceState.getInt("endHour")
        endTimeSelector.minute = savedInstanceState.getInt("endMinute")
        titleSelector.setText(savedInstanceState.getString("title"))
        descriptionSelector.setText(savedInstanceState.getString("description"))
    }

    fun addNevEvent(view: View) {
        if(titleSelector.text.toString() == ""){
            titleSelector.error = "Title is required"
            return
        }
        if(startTimeSelector.hour > endTimeSelector.hour || (startTimeSelector.hour == endTimeSelector.hour && startTimeSelector.minute >= endTimeSelector.minute)){
            Toast.makeText(this, "Start time must be before end time", Toast.LENGTH_SHORT).show()
            return
        }
        DatabaseManager.getInstance().addEvent(date,
            titleSelector.text.toString(),
            LocalTime.of(startTimeSelector.hour, startTimeSelector.minute),
            LocalTime.of(endTimeSelector.hour, endTimeSelector.minute),
            descriptionSelector.text.toString()
        )
        finish()
    }
}