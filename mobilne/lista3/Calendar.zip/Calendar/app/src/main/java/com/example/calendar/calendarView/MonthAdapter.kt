package com.example.calendar.calendarView

import android.graphics.Color
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.calendar.R
import com.example.calendar.database.DatabaseManager
import java.time.LocalDate

class MonthAdapter(var daysOfMonth: Array<String>, var date: LocalDate): RecyclerView.Adapter<MonthViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MonthViewHolder {
        var inflater = LayoutInflater.from(parent.context)
        var view = inflater.inflate(R.layout.calendar_cell, parent, false)
        var layoutParams = view.layoutParams
        layoutParams.height = parent.measuredHeight / 6
        return MonthViewHolder(view)
    }

    override fun onBindViewHolder(holder: MonthViewHolder, position: Int) {
        holder.dayOfMonth.text = daysOfMonth[position]
        holder.date = date.plusDays(position.toLong()-daysOfMonth.indexOf("1"))
        if(holder.date == LocalDate.now()) {
            holder.itemView.setBackgroundColor(Color.argb(150, 0, 255, 0))
        }else{
            holder.itemView.setBackgroundColor(Color.WHITE)
        }
        if(DatabaseManager.getInstance().hasEvent(holder.date)){
            holder.dayOfMonth.setBackgroundResource(R.drawable.red_circle_drawable)
        }else{
            holder.dayOfMonth.setBackgroundResource(0)
        }

    }

    override fun getItemCount(): Int {
        return daysOfMonth.size
    }
}