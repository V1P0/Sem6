package com.example.l1z1a

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    private var vl=0
    private var vr=0
    private var score=0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        roll()
    }

    fun roll(){
        vl = Random.nextInt(100)
        vr = Random.nextInt(99)
        if(vl<=vr) vr++
        findViewById<TextView>(R.id.score).text="Punkty: $score"
        findViewById<TextView>(R.id.buttonL).text=vl.toString()
        findViewById<TextView>(R.id.buttonR).text=vr.toString()
    }

    fun leftClick(view: View) {
        if(vl>vr) {
            score++
            Toast.makeText(this, "Brawo!", Toast.LENGTH_SHORT).show()
        }
        else {
            score--
            Toast.makeText(this, "Niestety!", Toast.LENGTH_SHORT).show()
        }
        roll()
    }
    fun rightClick(view: View) {
        if(vl<vr) {
            score++
            Toast.makeText(this, "Brawo!", Toast.LENGTH_SHORT).show()
        }
        else {
            score--
            Toast.makeText(this, "Niestety!", Toast.LENGTH_SHORT).show()
        }
        roll()
    }
}