package com.example.l1z2b;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private int[][] grid = new int[4][4];
    private int blankX = 3;
    private int blankY = 3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }

    private void init() {
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                grid[i][j] = (i * 4 + j + 1) % 16;
                if (grid[i][j] == 0) {
                    ((TextView) findViewById(getResources().getIdentifier("grid" + i + j, "id", getPackageName()))).setText("");
                } else {
                    ((TextView) findViewById(getResources().getIdentifier("grid" + i + j, "id", getPackageName()))).setText(String.valueOf(grid[i][j]));
                }
            }
        }
    }

    private void shuffle() {
        //array from 0 to 15
        List<Integer> array = new ArrayList<>();
        for (int i = 0; i < 16; i++) {
            array.add(i);
        }
        Collections.shuffle(array);
        //fill grid with shuffled array
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                grid[i][j] = array.get(i * 4 + j);
                if (grid[i][j] == 0) {
                    blankX = i;
                    blankY = j;
                    ((TextView) findViewById(getResources().getIdentifier("grid" + i + j, "id", getPackageName()))).setText("");
                } else {
                    ((TextView) findViewById(getResources().getIdentifier("grid" + i + j, "id", getPackageName()))).setText(String.valueOf(grid[i][j]));
                }
            }
        }
    }

    public void shuffle(View view) {
        shuffle();
    }

    public void up(View view) {
        if (blankX == 3) return;
        int temp = grid[blankX][blankY];
        grid[blankX][blankY] = grid[blankX + 1][blankY];
        grid[blankX + 1][blankY] = temp;
        ((TextView) findViewById(getResources().getIdentifier("grid" + blankX+blankY, "id", getPackageName()))).setText(String.valueOf(grid[blankX][blankY]));
        ((TextView) findViewById(getResources().getIdentifier("grid" + (blankX+1)+blankY, "id", getPackageName()))).setText("");
        blankX++;
    }

    public void right(View view) {
        if (blankY == 0) return;
        int temp = grid[blankX][blankY];
        grid[blankX][blankY] = grid[blankX][blankY - 1];
        grid[blankX][blankY - 1] = temp;
        ((TextView) findViewById(getResources().getIdentifier("grid" + blankX+blankY, "id", getPackageName()))).setText(String.valueOf(grid[blankX][blankY]));
        ((TextView) findViewById(getResources().getIdentifier("grid" + blankX+(blankY-1), "id", getPackageName()))).setText("");
        blankY--;
    }

    public void left(View view) {
        if (blankY == 3) return;
        int temp = grid[blankX][blankY];
        grid[blankX][blankY] = grid[blankX][blankY + 1];
        grid[blankX][blankY + 1] = temp;
        ((TextView) findViewById(getResources().getIdentifier("grid" + blankX+blankY, "id", getPackageName()))).setText(String.valueOf(grid[blankX][blankY]));
        ((TextView) findViewById(getResources().getIdentifier("grid" + blankX+(blankY+1), "id", getPackageName()))).setText("");
        blankY++;
    }

    public void down(View view) {
        if (blankX == 0) return;
        int temp = grid[blankX][blankY];
        grid[blankX][blankY] = grid[blankX - 1][blankY];
        grid[blankX - 1][blankY] = temp;
        ((TextView) findViewById(getResources().getIdentifier("grid" + blankX+blankY, "id", getPackageName()))).setText(String.valueOf(grid[blankX][blankY]));
        ((TextView) findViewById(getResources().getIdentifier("grid" + (blankX-1)+blankY, "id", getPackageName()))).setText("");
        blankX--;
    }

}
