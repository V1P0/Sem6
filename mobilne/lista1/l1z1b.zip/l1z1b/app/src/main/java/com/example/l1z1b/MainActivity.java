package com.example.l1z1b;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private int vl=0,vr=0,score=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        roll();
    }

    private void roll(){
        vl = new Random().nextInt(100);
        vr = new Random().nextInt(99);
        if(vl<=vr) vr++;
        ((TextView)findViewById(R.id.score)).setText("Score: "+score);
        ((Button)findViewById(R.id.buttonL)).setText(""+vl);
        ((Button)findViewById(R.id.buttonR)).setText(""+vr);
    }

    public void leftClick(View view) {
        if(vl>vr) {
            score++;
            Toast.makeText(this, "Brawo!", Toast.LENGTH_SHORT).show();
        }
        else {
            score--;
            Toast.makeText(this, "Niestety!", Toast.LENGTH_SHORT).show();
        }
        roll();
    }

    public void rightClick(View view) {
        if(vl<vr) {
            score++;
            Toast.makeText(this, "Brawo!", Toast.LENGTH_SHORT).show();
        }
        else {
            score--;
            Toast.makeText(this, "Niestety!", Toast.LENGTH_SHORT).show();
        }
        roll();
    }
}