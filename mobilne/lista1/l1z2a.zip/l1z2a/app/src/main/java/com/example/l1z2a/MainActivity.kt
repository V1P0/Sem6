package com.example.l1z2a

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    private var grid = Array(4) { Array(4) { 0 } }
    //4x4 grid of TestViews
    private var blankX = 3
    private var blankY = 3

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        init()
    }

    fun init(){
        for(i in 0..3){
            for(j in 0..3){
                grid[i][j] = (i*4+j+1)%16
                if(grid[i][j]==0){
                    findViewById<TextView>(resources.getIdentifier("grid$i$j", "id", packageName)).text = ""
                }else{
                    findViewById<TextView>(resources.getIdentifier("grid$i$j", "id", packageName)).text = grid[i][j].toString()
                }
            }
        }
    }



    fun shuffle(){
        var arr = Array(16){it}
        arr.shuffle()
        for(i in 0..3){
            for(j in 0..3){
                grid[i][j] = arr[i*4+j]
                if(grid[i][j]==0){
                    blankX = i
                    blankY = j
                    findViewById<TextView>(resources.getIdentifier("grid$i$j", "id", packageName)).text = ""
                }else{
                    findViewById<TextView>(resources.getIdentifier("grid$i$j", "id", packageName)).text = grid[i][j].toString()
                }
            }
        }

    }


    fun shuffle(view: View) {
        shuffle()
    }

    fun left(view:View){
        if(blankY==3) return
        val temp = grid[blankX][blankY]
        grid[blankX][blankY] = grid[blankX][blankY+1]
        grid[blankX][blankY+1] = temp
        findViewById<TextView>(resources.getIdentifier("grid$blankX$blankY", "id", packageName)).text = grid[blankX][blankY].toString()
        findViewById<TextView>(resources.getIdentifier("grid$blankX${blankY+1}", "id", packageName)).text = ""
        blankY++

    }

    fun up(view:View){
        if(blankX==3) return
        val temp = grid[blankX][blankY]
        grid[blankX][blankY] = grid[blankX+1][blankY]
        grid[blankX+1][blankY] = temp
        findViewById<TextView>(resources.getIdentifier("grid$blankX$blankY", "id", packageName)).text = grid[blankX][blankY].toString()
        findViewById<TextView>(resources.getIdentifier("grid${blankX+1}$blankY", "id", packageName)).text = ""
        blankX++

    }

    fun right(view:View){
        if(blankY==0) return
        val temp = grid[blankX][blankY]
        grid[blankX][blankY] = grid[blankX][blankY-1]
        grid[blankX][blankY-1] = temp
        findViewById<TextView>(resources.getIdentifier("grid$blankX$blankY", "id", packageName)).text = grid[blankX][blankY].toString()
        findViewById<TextView>(resources.getIdentifier("grid$blankX${blankY-1}", "id", packageName)).text = ""
        blankY--
    }

    fun down(view:View){
        if(blankX==0) return
        val temp = grid[blankX][blankY]
        grid[blankX][blankY] = grid[blankX-1][blankY]
        grid[blankX-1][blankY] = temp
        findViewById<TextView>(resources.getIdentifier("grid$blankX$blankY", "id", packageName)).text = grid[blankX][blankY].toString()
        findViewById<TextView>(resources.getIdentifier("grid${blankX-1}$blankY", "id", packageName)).text = ""
        blankX--
    }


}